// Arquivo: src/api/auth.routes.js (VERSÃO ESM)

import express from 'express';
import jwt from 'jsonwebtoken';
import * as userService from '../services/userService.js';
import { authenticateToken } from '../middleware/auth.middleware.js';

const router = express.Router();

// Rota de Login: POST /api/auth/login
router.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ message: 'Usuário e senha são obrigatórios.' });
  }
  try {
    const user = userService.findUserByUsername(username);
    if (!user) {
      return res.status(401).json({ message: 'Usuário ou senha inválidos.' });
    }
    const isPasswordValid = userService.verifyPassword(password, user.password_hash);
    if (!isPasswordValid) {
      return res.status(401).json({ message: 'Usuário ou senha inválidos.' });
    }
    const payload = {
      id: user.id,
      username: user.username,
      isAdmin: Boolean(user.is_admin),
    };
    const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '8h' });
    res.status(200).json({
      message: 'Login bem-sucedido!',
      token: token,
      user: payload,
    });
  } catch (error) {
    console.error('Erro no login:', error);
    res.status(500).json({ message: 'Erro interno no servidor.' });
  }
});

// Rota de teste protegida: GET /api/auth/profile
router.get('/profile', authenticateToken, (req, res) => {
  res.json({
    message: 'Você acessou uma rota protegida!',
    userProfile: req.user,
  });
});


// A MUDANÇA MAIS IMPORTANTE: 'module.exports' para 'export default'
export default router;