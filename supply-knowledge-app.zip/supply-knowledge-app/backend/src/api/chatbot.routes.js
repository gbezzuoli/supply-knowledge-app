// Arquivo: src/api/chatbot.routes.js (VERSÃO ESM)

import express from 'express';
import { authenticateToken } from '../middleware/auth.middleware.js';
import * as geminiService from '../services/geminiService.js';
import * as chromaService from '../services/chromaService.js';

const router = express.Router();

// POST /api/chatbot/ask
router.post('/ask', authenticateToken, async (req, res) => {
  const { query } = req.body;

  if (!query) {
    return res.status(400).json({ message: 'A query (pergunta) é obrigatória.' });
  }

  try {
    const queryEmbedding = await geminiService.generateEmbedding(query);
    const resultsChats = await chromaService.queryCollection('chatbot_resolucoes', queryEmbedding, 2);
    const resultsDocs = await chromaService.queryCollection('chatbot_documentacao', queryEmbedding, 1);

    let context = "";
    if (resultsChats && resultsChats.documents && resultsChats.documents.length > 0 && resultsChats.documents[0].length > 0) {
      context += "CONTEXTO DE RESOLUÇÕES DE CHAT (Prioridade Alta):\n";
      for (let i = 0; i < resultsChats.documents[0].length; i++) {
        context += `- Pergunta similar: ${resultsChats.metadatas[0][i].pergunta}\n  Solução: ${resultsChats.documents[0][i]}\n\n`;
      }
    }
    if (resultsDocs && resultsDocs.documents && resultsDocs.documents.length > 0 && resultsDocs.documents[0].length > 0) {
      context += "CONTEXTO DA DOCUMENTAÇÃO OFICIAL (Complementar):\n";
      for (let i = 0; i < resultsDocs.documents[0].length; i++) {
        context += `- Tópico: ${resultsDocs.metadatas[0][i].pergunta}\n  Detalhes: ${resultsDocs.documents[0][i]}\n\n`;
      }
    }
    if (!context) {
      context = "Nenhum contexto relevante foi encontrado nas bases de conhecimento.\n";
    }

    const finalPrompt = `Você é o CHATBOT-Guilherme, um assistente especialista direto e objetivo. Responda à pergunta do usuário usando o CONTEXTO fornecido. Se o contexto não for suficiente, admita que não encontrou a informação.\n\nCONTEXTO:\n${context}\n---\nPERGUNTA DO USUÁRIO: ${query}\n\nSUA RESPOSTA:`;
    const finalResponse = await geminiService.generateChatResponse(finalPrompt);

    res.status(200).json({ answer: finalResponse });
  } catch (error) {
    console.error('Erro no endpoint do chatbot:', error);
    res.status(500).json({ message: 'Ocorreu um erro ao processar sua pergunta.' });
  }
});

// MUDANÇA IMPORTANTE NO FINAL DO ARQUIVO
export default router;