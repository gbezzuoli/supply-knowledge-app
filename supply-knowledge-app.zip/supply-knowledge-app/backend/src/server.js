import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { setupDatabase } from './services/databaseService.js';
import authRoutes from './api/auth.routes.js';
import chatbotRoutes from './api/chatbot.routes.js';
import dataRoutes from './api/data.routes.js';

// 2. Inicialização do App
const app = express();
const PORT = process.env.PORT || 3001; // Usa a porta do .env ou 3001 como padrão

// 3. Middlewares
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));
app.use('/api/data', dataRoutes); // <-- Registre

// 4. Definição das Rotas
// Diz ao Express que todas as rotas que começarem com /api/auth devem ser gerenciadas pelo authRoutes
app.use('/api/auth', authRoutes);
app.use('/api/chatbot', chatbotRoutes);

// Rota de teste para ver se o servidor está funcionando
app.get('/', (req, res) => {
  res.send('<h1>Servidor do CHATBOT-Guilherme está no ar!</h1>');
});

// 5. Inicia o Servidor
app.listen(PORT, () => {
  // Antes de o servidor começar a "ouvir", configuramos o banco de dados.
  try {
    setupDatabase();
    console.log('Banco de dados conectado e configurado com sucesso.');
    console.log(`🚀 Servidor rodando na porta ${PORT}`);
  } catch (err) {
    console.error('Falha ao iniciar o servidor:', err);
    process.exit(1); // Encerra o processo se o DB falhar
  }
});

