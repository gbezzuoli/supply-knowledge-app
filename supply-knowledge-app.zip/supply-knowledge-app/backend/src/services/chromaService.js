// Arquivo: src/services/chromaService.js
// (Versão final e explícita para conexão com Docker)

const { ChromaClient } = require('chromadb');
const geminiService = require('./geminiService.js');

// 1. A MUDANÇA CRUCIAL ESTÁ AQUI:
// Nós estamos explicitamente dizendo ao cliente para se conectar
// ao servidor Docker na porta 8000.
const client = new ChromaClient({
  host: 'localhost',
  port: '8000'
});

// O resto do código permanece o mesmo.

class CustomGoogleEmbeddingFunction {
  async generate(texts) {
    const embeddings = await Promise.all(
      texts.map(text => geminiService.generateEmbedding(text))
    );
    return embeddings;
  }
}

const embedder = new CustomGoogleEmbeddingFunction();

async function getOrCreateCollection(collectionName) {
  try {
    const collection = await client.getOrCreateCollection({
      name: collectionName,
      embeddingFunction: embedder
    });
    console.log(`Coleção '${collectionName}' acessada/criada com sucesso via Docker.`);
    return collection;
  } catch (error) {
    console.error(`Erro ao acessar a coleção '${collectionName}':`, error);
    if (error.message.includes('fetch failed')) {
        console.error("DICA: Verifique se o contêiner Docker do ChromaDB está rodando na porta 8000.");
    }
    throw error;
  }
}

async function queryCollection(collectionName, queryEmbedding, nResults = 3) {
  try {
    const collection = await getOrCreateCollection(collectionName);
    const results = await collection.query({
      queryEmbeddings: [queryEmbedding],
      nResults: nResults
    });
    return results;
  } catch (error) {
    console.error(`Erro ao buscar na coleção '${collectionName}':`, error);
    throw error;
  }
}

module.exports = {
  client,
  getOrCreateCollection,
  queryCollection
};