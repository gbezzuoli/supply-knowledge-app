// Arquivo: src/services/dataProcessingService.js

const cheerio = require('cheerio');
const geminiService = require('./geminiService.js'); // <-- 1. Importe o serviço do Gemini

/**
 * Extrai as iniciais de um nome completo.
 * @param {string} fullName - O nome completo.
 * @returns {string} As iniciais (ex: "Guilherme T").
 */
function getInitials(fullName) {
  if (!fullName || !fullName.trim()) return "XX";
  const parts = fullName.trim().split(' ');
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

/**
 * Analisa o conteúdo de um arquivo HTML de transcrições de chat.
 * @param {string} htmlContent - O conteúdo do arquivo HTML.
 * @returns {Array<Object>} Um array de objetos, cada um representando um chat.
 */
function runParserHtml(htmlContent) {
  const $ = cheerio.load(htmlContent);
  const chats = [];

  $('h2').each((position, header) => {
    const headerElem = $(header);
    const rightDivText = headerElem.find('div.right').text();

    const ipMatch = rightDivText.match(/IP:\s*([a-fA-F0-9:.]+)/);
    const idMatch = rightDivText.match(/ID:\s*(\d+)/);

    if (!ipMatch || !idMatch) return; // 'continue' para o próximo 'each'

    const chatId = idMatch[1].trim();

    // Remove a div para pegar o texto principal do h2
    const mainText = headerElem.clone().find('div').remove().end().text().trim();
    const mainMatch = mainText.match(/(.+?),\s*(\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2})/);

    if (!mainMatch) return;

    const visitante = mainMatch[1].trim();
    const inicioChatStr = mainMatch[2].trim();

    const chatData = {
      chat_id: chatId,
      visitante: visitante,
      inicio_chat: inicioChatStr,
      mensagens: [],
    };

    let operatorInitials = "XX";
    let foundOperator = false;

    // Itera sobre os irmãos do h2 até o próximo h2
    let currentElement = headerElem.next();
    while (currentElement.length && !currentElement.is('h2')) {
      if (currentElement.is('div.message-row')) {
        const authorSpan = currentElement.find('span.usr-tit');
        if (authorSpan.length) {
          const authorName = authorSpan.text().trim().replace(':', '');
          const tipoAutor = authorSpan.hasClass('op-tit') ? "Operador" : "Visitante";

          if (!foundOperator && tipoAutor === 'Operador') {
            operatorInitials = getInitials(authorName);
            foundOperator = true;
          }
          
          // Extrai o texto da mensagem, removendo spans e limpando
          const messageText = currentElement.clone().find('span, div.msg-date').remove().end().html()
              .replace(/<br\s*\/?>/gi, '\n') // Substitui <br> por nova linha
              .trim();
          const finalText = $('<textarea/>').html(messageText).text().trim(); // Decodifica entidades HTML

          chatData.mensagens.push({
            autor: authorName,
            tipo_autor: tipoAutor,
            texto: finalText || "[Arquivo Anexado]",
          });
        }
      }
      currentElement = currentElement.next();
    }

    if (chatData.mensagens.length > 0) {
      // A lógica do 'chat_index' pode ser simplificada ou mantida se necessário
      chatData.chat_index = `${new Date(inicioChatStr).getMonth() + 1}${position}${operatorInitials}`;
      chats.push(chatData);
    }
  });

  return chats;
}

/**
 * Consolida os chats extraídos em problemas e soluções.
 * @param {Array<Object>} originalChats - O array de chats do parser.
 * @returns {Array<Object>} Um array de chats consolidados.
 */
function runConsolidador(originalChats) {
  const closingPhrases = ["encerrado por inatividade", "encerrado por falta de resposta"];
  const consolidatedChats = [];

  for (const chat of originalChats) {
    const problemaBrutoLista = [];
    const solucaoBrutaLista = [];

    for (const mensagem of chat.mensagens) {
      const texto = mensagem.texto.trim();
      if (!texto) continue;

      if (mensagem.tipo_autor === 'Visitante') {
        problemaBrutoLista.push(texto);
      } else if (mensagem.tipo_autor === 'Operador') {
        if (texto.toLowerCase().includes("seja bem-vindo ao suporte")) continue;
        solucaoBrutaLista.push(texto);
      }
    }

    const problemaBrutoStr = problemaBrutoLista.join('\n');
    const solucaoBrutaStr = solucaoBrutaLista.join('\n');

    if (!problemaBrutoStr || !solucaoBrutaStr) continue;
    if (closingPhrases.some(phrase => solucaoBrutaStr.toLowerCase().includes(phrase))) continue;

    consolidatedChats.push({
      chat_index: chat.chat_index,
      visitante: chat.visitante,
      analisado: false, // Propriedade do script python original
      problema_bruto: problemaBrutoStr,
      solucao_bruta: solucaoBrutaStr,
    });
  }

  return consolidatedChats;
}

// 3. NOVA FUNÇÃO: Gera pares de Q&A a partir dos chats consolidados
/**
 * @param {Array<Object>} consolidatedChats - Array de chats consolidados.
 * @returns {Promise<Array<Object>>} Uma promessa que resolve para um array de pares Q&A.
 */
async function runGerarKb(consolidatedChats) {
  // 2. ADICIONAR NOVA FUNÇÃO
  const knowledgeBase = [];
  const batchSize = 5; // Processar em lotes de 5 para não sobrecarregar a API

  console.log(`Iniciando geração da KB para ${consolidatedChats.length} chats...`);

  for (let i = 0; i < consolidatedChats.length; i += batchSize) {
    const batch = consolidatedChats.slice(i, i + batchSize);
    console.log(`Processando lote ${i / batchSize + 1}...`);

    // Monta o mega-prompt para o lote, exatamente como no script Python
    const dialogosParaAnalise = batch.map(chat => 
      `--- \nCHAT_ID_ORIGINAL: ${chat.chat_index}\nPROBLEMA DO CLIENTE:\n${chat.problema_bruto}\nSOLUÇÃO DO OPERADOR:\n${chat.solucao_bruta}\n---`
    ).join('\n');

    const promptTemplate = `
      Sua tarefa é analisar uma lista de diálogos e, para CADA um, extrair um par Q&A e tags.
      O resultado deve ser uma LISTA DE OBJETOS JSON VÁLIDA.
      REGRAS:
      1. Para cada diálogo, crie um objeto JSON com chaves "pergunta", "resposta", "tags" e "fonte_chat_index".
      2. 'fonte_chat_index' DEVE ser o valor exato do CHAT_ID_ORIGINAL.
      3. Retorne APENAS a lista JSON \`[ {{...}}, {{...}} ]\`. Não inclua nenhum outro texto ou formatação como \`\`\`json.
      EXEMPLO DE SAÍDA: [{"pergunta": "Como corrigir erro de ICMS?", "resposta": "Acesse Fiscal > Configs e marque...", "tags": ["nfe", "icms"], "fonte_chat_index": "41GR8"}]
      --- LOTE DE DIÁLOGOS PARA ANÁLISE:
      ${dialogosParaAnalise}
      ---
    `;

    try {
      const responseText = await geminiService.generateChatResponse(promptTemplate);
      
      // Limpa a resposta para garantir que seja um JSON válido
      const cleanedResponse = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
      
      const qaPairs = JSON.parse(cleanedResponse);
      
      // Adiciona os pares Q&A válidos à nossa base de conhecimento
      if (Array.isArray(qaPairs)) {
        knowledgeBase.push(...qaPairs);
      }
    } catch (error) {
      console.error(`Erro ao processar o lote ${i / batchSize + 1}:`, error);
      // Continua para o próximo lote em caso de erro
    }
    // Adiciona uma pequena pausa para não exceder os limites da API
    await new Promise(resolve => setTimeout(resolve, 1000)); // 1 segundo de pausa
  }
  
  console.log(`Geração da KB concluída. ${knowledgeBase.length} itens criados.`);
  return knowledgeBase;
}

module.exports = {
  runParserHtml,
  runConsolidador,
  runGerarKb, // <-- 3. EXPORTAR NOVA FUNÇÃO
};