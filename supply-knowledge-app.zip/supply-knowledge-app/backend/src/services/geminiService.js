// Arquivo: src/services/geminiService.js (VERSÃO ESM FINAL)
import { GoogleGenerativeAI } from '@google/genai';

if (!process.env.GOOGLE_API_KEY) {
  throw new Error('Chave de API do Google não encontrada no arquivo .env');
}

const genAI = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY);

const embeddingModel = genAI.getGenerativeModel({ model: 'text-embedding-latest' });
const generationModel = genAI.getGenerativeModel({ model: 'gemini-2.5-pro-latest' });

export async function generateEmbedding(text) {
  try {
    const result = await embeddingModel.embedContent(text);
    return result.embedding.values;
  } catch (error) {
    console.error('Erro ao gerar embedding:', error);
    throw error;
  }
}

export async function generateChatResponse(prompt) {
  try {
    const result = await generationModel.generateContent(prompt);
    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error('Erro ao gerar resposta do chat:', error);
    throw error;
  }
}

export { generationModel };