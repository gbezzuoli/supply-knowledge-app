// Arquivo: src/services/userService.js

const { db } = require('./databaseService.js');
const bcrypt = require('bcryptjs');

function findUserByUsername(username) {
  const stmt = db.prepare('SELECT * FROM users WHERE username = ?');
  return stmt.get(username);
}

function verifyPassword(password, hash) {
  return bcrypt.compareSync(password, hash);
}

module.exports = {
  findUserByUsername,
  verifyPassword,
};