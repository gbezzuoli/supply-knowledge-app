// Arquivo: src/services/databaseService.js (VERSÃO ESM COMPLETA)

// --- 1. MUDANÇA: 'require' para 'import' ---
import Database from 'better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url'; // Módulo extra para o truque do __dirname
import bcrypt from 'bcryptjs';

// --- 2. MUDANÇA: O truque para recriar '__dirname' em ES Modules ---
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// O resto do código tem a mesma lógica de antes
const dbPath = path.resolve(__dirname, '..', '..', 'users.db');
const db = new Database(dbPath, { verbose: console.log });

// A função `setupDatabase` não precisa de nenhuma alteração interna
function setupDatabase() {
  console.log('Verificando e configurando o banco de dados...');

  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      is_admin BOOLEAN NOT NULL DEFAULT 0
    )
  `);

  db.exec(`
    CREATE TABLE IF NOT EXISTS permissions (
      user_id INTEGER,
      permission TEXT,
      PRIMARY KEY(user_id, permission),
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    )
  `);

  const adminUser = db.prepare('SELECT id FROM users WHERE username = ?').get('FABIO');

  if (!adminUser) {
    console.log("Usuário 'FABIO' não encontrado. Criando...");
    const passwordHash = bcrypt.hashSync('softland', 10);
    db.prepare(
      'INSERT INTO users (username, password_hash, is_admin) VALUES (?, ?, ?)'
    ).run('FABIO', passwordHash, 1);
    console.log("Usuário 'FABIO' criado com sucesso.");
  } else {
    db.prepare('UPDATE users SET is_admin = 1 WHERE username = ?').run('FABIO');
    console.log("Usuário 'FABIO' já existe. Privilégios de admin garantidos.");
  }
}

// --- 3. MUDANÇA: 'module.exports' para 'export' ---
export { db, setupDatabase };