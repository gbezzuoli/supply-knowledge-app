// Arquivo: inspect_db.js
// Um script simples para inspecionar o conteúdo de uma coleção no ChromaDB.

const { ChromaClient } = require('chromadb');

// -- CONFIGURAÇÃO --
// Altere o nome da coleção que você quer inspecionar
const COLLECTION_TO_INSPECT = 'chatbot_resolucoes'; // ou 'chatbot_documentacao'

// Função principal assíncrona
async function inspectCollection() {
  console.log('Tentando se conectar ao servidor ChromaDB em http://localhost:8000...');
  
  // Conecta-se ao servidor Docker do ChromaDB
const client = new ChromaClient({
  host: 'localhost',
  port: '8000'
});

  try {
    console.log(`Buscando a coleção: "${COLLECTION_TO_INSPECT}"...`);
    const collection = await client.getCollection({ name: COLLECTION_TO_INSPECT });

    // O método .get() busca os dados. Podemos filtrar ou pegar tudo.
    // O include[] especifica o que queremos ver: metadados e os próprios documentos.
    const allData = await collection.get({
      include: ["metadatas", "documents"]
    });

    const count = allData.ids.length;
    console.log(`\n--- INSPECIONANDO COLEÇÃO: "${COLLECTION_TO_INSPECT}" ---`);
    console.log(`Total de documentos encontrados: ${count}\n`);

    if (count === 0) {
      console.log('A coleção está vazia.');
      return;
    }

    // Itera sobre os dados e imprime de forma legível
    for (let i = 0; i < count; i++) {
      console.log(`----------------------------------------`);
      console.log(`| Documento ID: ${allData.ids[i]}`);
      console.log(`| Metadados:`);
      // Imprime cada par chave-valor dos metadados
      for (const key in allData.metadatas[i]) {
        console.log(`|   - ${key}: ${allData.metadatas[i][key]}`);
      }
      console.log(`|`);
      console.log(`| Conteúdo (Documento):`);
      console.log(`|   ${allData.documents[i].replace(/\n/g, '\n|   ')}`); // Formata para multilinhas
      console.log(`----------------------------------------\n`);
    }

  } catch (error) {
    if (error.message && error.message.includes('404')) {
        console.error(`\nERRO: A coleção "${COLLECTION_TO_INSPECT}" não foi encontrada no banco de dados.`);
        console.error('Verifique se o nome está correto e se os dados foram migrados corretamente.');
    } else if (error.message && error.message.includes('fetch failed')) {
        console.error('\nERRO: Falha ao conectar ao ChromaDB. Verifique se o contêiner Docker está rodando.');
    } else {
        console.error('\nOcorreu um erro inesperado:', error);
    }
  }
}

// Executa a função
inspectCollection();